#include "Beep.h"
#include "msp430f6638.h"
#include "string.h"
#include "cd4052.h"
#include "DRV8833.H"
#include "ADC.h"
#include "dc_motor.h"
#include "Timer.h"
#include "Segment_LCD.h"
#include "HAL_PMM.H"
#include "HAL_UCS.H"
#include "Frequency_dection.h"
#include "Uart.h"
#include "LCD.h"
#include "tm1638.h"


#define BEEP_PIN BIT0
#define BEEP_DELAY 10000

void Beep_Init() {
    //P5OUT &= ~BIT1;  // ��ʼ״̬�¹رշ�����
    DAC12_0CTL0 = DAC12IR + DAC12SREF_1 + DAC12AMP_5 + DAC12ENC + DAC12CALON+DAC12OPS;
    P5DIR=BIT1;
    // P4DIR=BIT1;
    P5OUT&=~BIT1;




}

void Beep_Pwm(unsigned int time){

	int i=0;

	for(i;i<time;i++)
	  {
		DAC12_0DAT=1000;
		  __delay_cycles(2000);
		DAC12_0DAT=900;
		  __delay_cycles(2000);
	  }
}

void Beep_One(void){

	Beep_Pwm(3000);
	 __delay_cycles(2000);

}
