#ifndef BEEP_H
#define BEEP_H


#define BEEP_PIN BIT0
#define BEEP_DELAY 10000

void Beep_Init();
void Beep_Pwm(unsigned int time);
void Beep_One(void);
#endif
