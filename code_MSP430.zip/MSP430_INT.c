/**
  ******************************************************************************
  * @�ļ��� MSP430_INT.c
  * @����   DY
  * @�汾   V1.0
  * @����   03/12/2012
  * @ժҪ   ��Ҫ�����ļ�������
  ******************************************************************************
  * @Copyright (c)2012,�Ϻ����е��ӿƼ����޹�˾
  * @All right reserved.
  */

/* Includes ------------------------------------------------------------------*/
#include "msp430f6638.h"
#include "stdint.h"

#include "Frequency_dection.h"
#include "Segment_LCD.h"
#include "Uart.h"
#include "math.h"
#include "Beep.h"
extern int8_t ADC_FLAG;

extern unsigned int G_DC_Speed;  //DC_Motor ֱ�����"1����CCR3��������Ƶ�ʴ���
extern unsigned int G_DC_SpeedCnt;
extern char* receivedString[20];
//extern unsigned int F_1s_Frequency_DC_Motor;//�ж��Ƿ�Ϊ��ʱ��������ʱ
/* Private typedef -----------------------------------------------------------*/

/* Private define ------------------------------------------------------------*/
#define   Num_of_Results   8
#define   Num_of_Str       20
#define CPU_F ((double)1000000)
#define delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))
#define delay_ms(x) __delay_cycles((long)(CPU_F*(double)x/1000.0))
/* Private macro -------------------------------------------------------------*/
int index_str = 0;

int flag_Uartsend = 0;//////////////////yhy
int flag_Timesend = 1;
double DC_Times ;
volatile unsigned int results[Num_of_Results];
volatile unsigned char str_rx[Num_of_Str];
unsigned char CharSpeed[6];  // ���ڴ洢ÿ�����ֵ�����
unsigned char CharTimes[6];  // ���ڴ洢ÿ�����ֵ�����

/*!
*�������ܣ�ADC�жϷ�����
*�����������
*�����������
*����ֵ��  ��
*/
void uintToString(void)
{
    unsigned int number = G_DC_Speed;
    int digits = 0;
    int cnt = 1;

    int temp1 = number;
    int temp2 = number;

    while (temp1 != 0)
    {
    	int digit = temp1 % 10;
		temp1 /= 10;
		digits++;
    }

    while (temp2 != 0)
    {
    	int i = temp2 % 10;
		temp2 /= 10;
		CharSpeed[digits - cnt] = '0' + i;
		cnt++;
    }

    CharSpeed[digits] = '\0';

}

void doubleToString(void)
{
    unsigned int number =round(DC_Times);
    int digits = 0;
    int cnt = 1;

    int temp1 = number;
    int temp2 = number;

    while (temp1 != 0)
    {
    	int digit = temp1 % 10;
		temp1 /= 10;
		digits++;
    }

    while (temp2 != 0)
    {
    	int i = temp2 % 10;
		temp2 /= 10;
		CharTimes[digits - cnt] = '0' + i;
		cnt++;
    }

    CharTimes[digits] = '\0';

}




#pragma vector=ADC12_VECTOR
__interrupt void ADC12ISR (void)
{
  static unsigned char index = 0;

  switch(__even_in_range(ADC12IV,34))
  {
  case  0: break;                           // Vector  0:  No interrupt
  case  2: break;                           // Vector  2:  ADC overflow
  case  4: break;                           // Vector  4:  ADC timing overflow
  case  6: break;                           // Vector  6:  ADC12IFG0
  case  8: break;                           // Vector  8:  ADC12IFG1
  case 10: break;                           // Vector 10:  ADC12IFG2
  case 12: break;                           // Vector 12:  ADC12IFG3
  case 14: break;                           // Vector 14:  ADC12IFG4
  case 16: break;                           // Vector 16:  ADC12IFG5
  case 18:                                  // Vector 18:  ADC12IFG6
  results[index] = ADC12MEM6;               // Move results
  index++;                                  // Increment results index, modulo; Set Breakpoint1 here

  if (index == 8)
  {
    index = 0;
    ADC_FLAG = 1;
  }
  break;
  case 20: break;                           // Vector 20:  ADC12IFG7
  case 22: break;                           // Vector 22:  ADC12IFG8
  case 24: break;                           // Vector 24:  ADC12IFG9
  case 26: break;                           // Vector 26:  ADC12IFG10
  case 28: break;                           // Vector 28:  ADC12IFG11
  case 30: break;                           // Vector 30:  ADC12IFG12
  case 32: break;                           // Vector 32:  ADC12IFG13
  case 34: break;                           // Vector 34:  ADC12IFG14
  default: break;
  }
}



/*!
*�������ܣ�TIMER1�жϷ�����-����ʵ�ֲ��������ÿһ��֮���ʱ����
*�����������
*�����������
*����ֵ��  ��
*/

// Timer1 A0 interrupt service routine
#pragma vector=TIMER1_A0_VECTOR
__interrupt void TIMER1_A0_ISR(void)
{

}

/*!
*�������ܣ�TIMER0�жϷ�����-����ʵ�ֲ��������ÿһ��֮���ʱ����
*�����������
*�����������
*����ֵ��  ��
*note:     Timer0_A5 CC1-4, TA
*/

#pragma vector = TIMER0_A1_VECTOR
__interrupt void Capture_Input_ISR(void)
{
  TA0CCTL3 &= ~CCIFG;//����жϱ�־
  G_DC_SpeedCnt++;
}

/*!
*�������ܣ�Timer0_B7�жϷ�����,������ʱ���²������
*�����������
*�����������
*����ֵ  ����
*note    ��Timer0_B7 CC0
*/
#pragma vector=TIMERB0_VECTOR
__interrupt void Update_Count_ISR(void)
{
	G_DC_Speed = G_DC_SpeedCnt;
	double D_Speed = G_DC_Speed;
	DC_Times = 1000000/D_Speed;
	LCD_Clear();




    if(flag_Uartsend) {
    	if(!flag_Timesend)
    	{
    		uintToString();
			Uart_Out("The Frequency of No.1  is ");
			Uart_Out(CharSpeed);
			Uart_Out(" Hz\n");}
    	else{
    		doubleToString();
			Uart_Out("The Time of No.1 is ");
			Uart_Out(CharTimes);
			Uart_Out(" us\n");}
    	}
    	//CharSpeed = "0";
    G_DC_SpeedCnt=0;
    TB0CCTL0 &= ~CCIFG;//����жϱ�־
 }



// Echo back RXed character, confirm TX buffer is ready first
#pragma vector=USCI_A1_VECTOR
__interrupt void USCI_A1_ISR(void)
{

  switch(__even_in_range(UCA1IV,4))
  {
  case 0:break;                             // Vector 0 - no interrupt
  case 2:                                   // Vector 2 - RXIFG

	 //while (!(UCA1IFG & UCRXIFG));
	      if(UCA1RXBUF == '1')
	 	    {
	 	    	Uart_Out("Success\n");
	 	    	Uart_Out("Frequency Dector\n");
	 	    	Uart_Out("1951706\n");
	 	    	Uart_Out("Huang Kaikang\n");
	 	    	flag_Uartsend = 0;
	 	    }
	 	    else if(UCA1RXBUF == '2')
	 	    {
	 	    	flag_Uartsend = 1;

	 	    }
	 	    else if(UCA1RXBUF == '3')
	 	   	{
	 	    	uintToString();
	 	   	    Uart_Out("Beep\n");
	 	   	    //Uart_Out(CharSpeed);
	 	   	    int i=0;
	 	   	    for(;i<3;i++)
	 	   	    {
	 	   	    	Beep_One();
	 	   	   	 	delay_ms(1000);

	 	   	    }

	 	   	    flag_Uartsend = 0;
	 	    }
	 	    else if(UCA1RXBUF == '4'){


	 	    	doubleToString();
	 	    	if(flag_Timesend)
 	    		{
	 	    		flag_Timesend = 0;
	 	    		Uart_Out("Frequency Mode");

 	    		}
	 	    	else
	 	    	{
	 	    		flag_Timesend = 1;
	 	    		Uart_Out("Time Mode");

	 	    	}
	 	    	flag_Uartsend = 0;

	 	    }
	 	    else{
	 	    	Uart_Out("Error\n");


	 	    }



	  break;

  case 4:break;                            // Vector 4 - TXIFG
  default: break;
  }
  }


#pragma vector=USCI_B1_VECTOR
__interrupt void USCI_B1_ISR(void)
{
  volatile unsigned int i;

  switch(__even_in_range(UCB1IV,4))
  {
    case 0: break;                          // Vector 0 - no interrupt
    case 2:                                 // Vector 2 - RXIFG
      break;
    case 4:                                 // Vector 4 - TXIFG
      break;
    default: break;
  }
}
