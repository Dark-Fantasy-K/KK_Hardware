/**
  ******************************************************************************
  * @�ļ��� Segment_LCD.h
  * @����   DY
  * @�汾   V1.0
  * @����   03/12/2012
  * @ժҪ   ��Ҫ�����ļ�������
  ******************************************************************************
  * @Copyright (c)2012,�Ϻ����е��ӿƼ����޹�˾
  * @All right reserved.
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __SEGMENT_H
#define __SEGMENT_H

/* Includes ------------------------------------------------------------------*/

/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions ------------------------------------------------------- */
void Init_lcd(void);
void LcdGo(unsigned char Dot);
void LcdBlink(unsigned char doit);
void LCD_Clear(void); //����
void Init_TS3A5017DR(void);
void Backlight_Enable(void);
void Write_Data(int data);
void Write_Data_2BIT(int ten,int one);


#endif /* __SEGMENT_H */
