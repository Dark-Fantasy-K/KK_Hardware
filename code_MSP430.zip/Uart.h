#ifndef __UARST_H
#define __UARST_H




void Init_UartConfig(void);
void Uart_Out(char* str);
void Uart_In(char* receivedString, int maxLength);
#endif /* __MSP430_INT_H */
