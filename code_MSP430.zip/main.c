/**
  ******************************************************************************
  * @�ļ��� main.c
  * @����   DY
  * @�汾   V1.0
  * @����   03/12/2012
  * @ժҪ   ����������Գ���
  ******************************************************************************
  * @Copyright (c)2012,�Ϻ����е��ӿƼ����޹�˾
  * @All right reserved.
  */

/* Includes ------------------------------------------------------------------*/
#include <msp430f6638.h>
#include <stdio.h>
#include "string.h"
#include "cd4052.h"
#include "DRV8833.H"
#include "ADC.h"
#include "dc_motor.h"
#include "Timer.h"
#include "Segment_LCD.h"
#include "HAL_PMM.H"
#include "HAL_UCS.H"
#include "Frequency_dection.h"
#include "Uart.h"
#include "LCD.h"
#include "tm1638.h"


extern uint16_t results[8];
#define CPU_F ((double)1000000)
#define delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))
#define delay_ms(x) __delay_cycles((long)(CPU_F*(double)x/1000.0))
uint8_t ADC_FLAG = 0;
uint8_t Update = 0; //����ܸ��±�־λ
uint16_t Pot_ADC_Result = 0 ;
extern unsigned int G_DC_Speed;
extern double DC_Times ;
extern unsigned char str_rx[20];
extern int flag_Timesend;

char SpeedStr[20];
const char tab[] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71};
/* Private function prototypes -----------------------------------------------*/
void Up_ClockFor_20MHZ(void);
void SPI_GPIO_Init(void);
void System_Init(void);
void TFTLCD_InitialDisplay(void);
void LED_Display(void);
//void uintToString(unsigned int value, char* str, int strSize);
void Message_Judge(void);
int main(void)
{
	System_Init();


	 while(1)
	 {
		 LED_Display();
		 LCD_Display();

	  }
}
void LCD_Display()
{
	 if(!flag_Timesend)
	    {
	    	Write_Data(G_DC_Speed);
	    }
	    else
	    {
	    	Write_Data(DC_Times);
		}


}




void Up_ClockFor_20MHZ(void)
{
	SetVCore(PMMCOREV_3);				        // Set Vcore to accomodate for max. allowed system speed
	UCSCTL3 |= SELREF_2;                      	// Set DCO FLL reference = REFO
	UCSCTL4 |= SELA_2;                        	// Set ACLK = REFO
	Init_FLL_Settle(20000, 630);		        // Set system clock to max (20MHz)
}

void System_Init(void)
{
	  WDTCTL = WDTPW + WDTHOLD;    // Stop WDT

	  //TFTLCD��ʾ
	  SPI_GPIO_Init();
	  Init_TFTLCDConfig();
	  //TFTLCD_InitialDisplay();

	  Up_ClockFor_20MHZ();         // ʱ�ӱ�Ƶ��20MHz

	  //��ʽLCD��ʼ��
	  Init_TS3A5017DR();       // Configure TS3A5017DR  IN1 and IN2
	  Init_lcd();              // LCD��ʼ��
	  Backlight_Enable();      // �򿪱���*/
	  LcdGo(1);                // ��Һ��ģ��
	  LCD_Clear();             // ����

	  //DC_MOTOR���ģ���ʼ��
	  CD4052_Configure();
	  DRV8833_Init();
	  Step_Timer_Init();           // ���ÿ��Ʋ�������Ķ�ʱ��
	  TIM_Capture_Config();        // �������벶��ͨ��
	  TIM_Update_Config();         // ���ö�ʱ������ʱ���²��������

	  //����ʹ��
	  Init_UartConfig();

	  //��������ʼ��
	  Beep_Init();
	  int i=0;
	  	 	   	    for(;i<3;i++)
	  	 	   	    {
	  	 	   	    	Beep_One();
	  	 	   	   	 	delay_ms(1000);

	  	 	   	    }
	  Uart_Out("Syetem Initial Successd\n");
	  Uart_Out("1951706\n");
	  Uart_Out("1.The System Information\n");
	  Uart_Out("2.The Measure Result\n");
	  Uart_Out("3.Beep Test\n");
	  Uart_Out("4.Mode Change\n");

	  //LED��ʼ��
	  init_TM1638();

	  TFTLCD_InitialDisplay();


	  __bis_SR_register(GIE);      // ʹ���ж�
}
void TFTLCD_InitialDisplay(void)
{
	 TFTLCD_Clear(GREEN);//LCDˢ��GREEN
	 SPI_Delay(20000);
	 TFTLCD_ShowString(0,0,"1951706");//��ʾ�ַ���
	 SPI_Delay(20000);
	 TFTLCD_ShowString(100,250,"Huang Kaikang");//��ʾ�ַ���
	 SPI_Delay(20000);
	 TFTLCD_ShowString(200,0,"���ǿ�");//��ʾ�ַ���
	 SPI_Delay(20000);
}
void LED_Display(void)
{
	//Write_allLED(0x00);
	unsigned int number;
	if(!flag_Timesend)
	{
		number = G_DC_Speed;
	}
	else
	{
		number = DC_Times;
	}
	unsigned int NumSpeed[6];  // ���ڴ洢ÿ�����ֵ�����
	int digits = 0;
	if (number == 0) {
		digits = 1;  // �������� 0����Ϊһλ��
    }
    else{
    	int temp = number;
    	while (temp != 0){
        int digit = temp % 10;
        temp /= 10;
        NumSpeed[digits] = digit;
        digits++;
    	}
    }
	int i = 0;
	if(digits==3)
		Write_DATA(0,0x00);
	for (; i < digits; i++) {
		if(digits - i <= 4)
			Write_DATA((4+i-digits)*2,tab[NumSpeed[digits - i - 1]]);

	}
}


void SPI_GPIO_Init(void)
{
  P8SEL |= BIT4+BIT5+BIT6;                  //Bit=1:Peripheral module function is selectedfor the pin
  P8DIR |=  BIT4+BIT5;                      //Port configured as output
  P8DIR &=  BIT6;                           //MISO ���ó�����

  // Configure TS3A5017DR  IN1 and IN2
  P3DIR |= BIT4 + BIT5;   //P3.4 : IN1 ; P3.5 : IN2   set as output
  P3OUT |= BIT4;          //IN1 = 1
  P3OUT &= ~BIT5;         //IN2 = 0
  P3DIR |= BIT7;
  P3OUT |= BIT7;

}



